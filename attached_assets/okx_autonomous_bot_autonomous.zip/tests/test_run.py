import os
from dotenv import load_dotenv

from src.core.bot import Bot

def test_bot_run():
    load_dotenv()
    bot = Bot(
        api_key=os.getenv("OKX_API_KEY", "test_key"),
        secret_key=os.getenv("OKX_SECRET_KEY", "test_secret"),
        passphrase=os.getenv("OKX_PASSPHRASE", "test_pass")
    )
    bot.run()

if __name__ == "__main__":
    test_bot_run()