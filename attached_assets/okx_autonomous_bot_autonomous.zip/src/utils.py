# Utility functions
def log(msg):
    print(msg)