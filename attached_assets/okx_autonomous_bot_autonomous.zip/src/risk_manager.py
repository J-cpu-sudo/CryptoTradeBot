class RiskManager:
    def approve(self, signal, data):
        # Allow buy/sell only if volume is above threshold
        if signal == "hold":
            return False
        return data.get("volume", 0) > 500