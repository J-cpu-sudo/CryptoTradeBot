import logging
from strategy import Strategy
from signals import SignalGenerator
from trader import Trader
from risk_manager import RiskManager

class Bot:
    def __init__(self, api_key, secret_key, passphrase):
        self.api_key = api_key
        self.secret_key = secret_key
        self.passphrase = passphrase

        self.strategy = Strategy()
        self.signal_generator = SignalGenerator()
        self.risk_manager = RiskManager()
        self.trader = Trader(api_key, secret_key, passphrase)

        self.logger = logging.getLogger(__name__)
        self.logger.info("Bot initialized.")

    def run(self):
        self.logger.info("Bot is running...")

        try:
            # Example: get strategy output
            market_data = self.strategy.get_data()
            signal = self.signal_generator.generate(market_data)

            self.logger.info(f"Signal generated: {signal}")

            if self.risk_manager.approve(signal, market_data):
                self.trader.execute(signal)
            else:
                self.logger.info("Trade rejected by risk manager.")

        except Exception as e:
            self.logger.exception(f"Error during bot run: {e}")