import time
import json
import base64
import hmac
import hashlib
import requests
import logging

class Trader:
    def __init__(self, api_key, secret_key, passphrase):
        self.api_key = api_key
        self.secret_key = secret_key
        self.passphrase = passphrase
        self.logger = logging.getLogger(__name__)
        self.dry_run = os.getenv("DRY_RUN", "true").lower() == "true"
        self.base_url = "https://www.okx.com"

    def _timestamp(self):
        return time.strftime('%Y-%m-%dT%H:%M:%S.000Z', time.gmtime())

    def _signature(self, timestamp, method, request_path, body=''):
        message = f"{timestamp}{method}{request_path}{body}"
        return base64.b64encode(
            hmac.new(self.secret_key.encode(), message.encode(), hashlib.sha256).digest()
        ).decode()

    def _headers(self, method, path, body=''):
        ts = self._timestamp()
        sign = self._signature(ts, method, path, body)
        return {
            'Content-Type': 'application/json',
            'OK-ACCESS-KEY': self.api_key,
            'OK-ACCESS-SIGN': sign,
            'OK-ACCESS-TIMESTAMP': ts,
            'OK-ACCESS-PASSPHRASE': self.passphrase,
            'x-simulated-trading': '0'
        }

    def execute(self, signal):
        if self.dry_run:
            self.logger.info(f"[DRY RUN] Would execute: {signal.upper()}")
            return

        side = "buy" if signal == "buy" else "sell"
        data = {
            "instId": "BTC-USDT",
            "tdMode": "cash",
            "side": side,
            "ordType": "market",
            "sz": "0.001"
        }
        body = json.dumps(data)
        try:
            url = f"{self.base_url}/api/v5/trade/order"
            headers = self._headers("POST", "/api/v5/trade/order", body)
            response = requests.post(url, headers=headers, data=body)
            result = response.json()
            self.logger.info(f"Trade result: {result}")
        except Exception as e:
            self.logger.exception("Trade execution failed")