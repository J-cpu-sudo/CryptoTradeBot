class SignalGenerator:
    def generate(self, data):
        # Very basic signal logic based on RSI
        if data["rsi"] < 30:
            return "buy"
        elif data["rsi"] > 70:
            return "sell"
        else:
            return "hold"