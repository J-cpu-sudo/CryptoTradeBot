import os
import time
import logging
from dotenv import load_dotenv
from src.core.bot import Bot

logging.basicConfig(level=logging.INFO)

def main():
    load_dotenv()
    bot = Bot(
        api_key=os.getenv("OKX_API_KEY"),
        secret_key=os.getenv("OKX_SECRET_KEY"),
        passphrase=os.getenv("OKX_PASSPHRASE")
    )

    while True:
        bot.run()
        time.sleep(60)

if __name__ == "__main__":
    main()