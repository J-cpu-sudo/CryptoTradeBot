class Strategy:
    def get_data(self):
        # Dummy data for demonstration
        return {
            "price": 100.0,
            "volume": 1000,
            "rsi": 45
        }