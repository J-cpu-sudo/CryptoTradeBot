import ccxt.async_support as ccxt
import os

exchange = ccxt.okx({
    'apiKey': os.getenv("OKX_API_KEY"),
    'secret': os.getenv("OKX_SECRET_KEY"),
    'password': os.getenv("OKX_PASSPHRASE"),
    'enableRateLimit': True
})

async def get_market_data():
    return await exchange.fetch_ticker('BTC/USDT')

async def place_order(data):
    price = data['last']
    # Simulate a market buy for $10 worth of BTC
    return await exchange.create_market_buy_order('BTC/USDT', 10 / price)
