# Config loader
import os
from dotenv import load_dotenv

def load_config():
    load_dotenv()
    return {
        'API_KEY': os.getenv('API_KEY'),
        'API_SECRET': os.getenv('API_SECRET')
    }